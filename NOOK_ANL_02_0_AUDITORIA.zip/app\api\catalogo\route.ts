import { NextResponse } from "next/server";
import { supabaseAdmin } from "../../../lib/supabase-admin";
import { getOperationSession } from "../../../lib/operation-auth";
import { authorizeOperationSession } from "@/lib/operation-rbac";

export async function GET() {
  const session = await getOperationSession();

  const authorization = authorizeOperationSession(
    session,
    "catalog.read",
  );

  if (!authorization.ok) {
    return NextResponse.json(
      { ok: false, message: authorization.message },
      { status: authorization.status },
    );
  }

  const { data: products, error: productsError } = await supabaseAdmin
    .from("products")
    .select(
      `
      id,
      sku,
      name,
      category,
      subcategory,
      operational_type,
      portion_quantity,
      has_flavors,
      max_flavors,
      allow_repeat_flavor,
      allows_toppings,
      max_toppings,
      allows_chocolate_dip,
      requires_preparation,
      is_active,
      sort_order,
      product_prices (
        id,
        channel,
        price_list,
        price,
        is_active
      ),
      product_option_prices (
        id,
        option_value_id,
        channel,
        price_list,
        price,
        inventory_quantity,
        is_active
      ),
      product_channels (
        channel_code,
        is_enabled
      ),
      product_option_rules (
        id,
        option_group_id,
        min_quantity,
        max_quantity,
        allow_repeat,
        is_required
      ),
      inventory_items (
        id,
        code,
        name,
        option_value_id,
        consumption_quantity,
        unit,
        inventory_source,
        is_active
      ),
      product_inventory_mappings (
        id,
        inventory_item_id,
        quantity,
        is_active,
        notes,
        inventory_items (
          id,
          code,
          name,
          item_type,
          unit,
          product_id,
          option_value_id,
          inventory_source,
          is_active
        )
      )
    `,
    )
    .order("sort_order", { ascending: true });

  if (productsError) {
    return NextResponse.json(
      { ok: false, message: productsError.message },
      { status: 500 },
    );
  }

  const { data: optionGroups, error: optionGroupsError } = await supabaseAdmin
    .from("catalog_option_groups")
    .select(
      `
      id,
      code,
      name,
      is_active,
      catalog_option_values (
        id,
        code,
        name,
        is_active,
        sort_order
      )
    `,
    )
    .order("id", { ascending: true });

  if (optionGroupsError) {
    return NextResponse.json(
      { ok: false, message: optionGroupsError.message },
      { status: 500 },
    );
  }

  const { data: salesChannels, error: salesChannelsError } = await supabaseAdmin
    .from("sales_channels")
    .select("code, name, channel_type, is_active, sort_order")
    .order("sort_order", { ascending: true });

  if (salesChannelsError) {
    return NextResponse.json(
      { ok: false, message: salesChannelsError.message },
      { status: 500 },
    );
  }

  const {
    data: inventoryComponentCandidates,
    error: inventoryComponentCandidatesError,
  } = await supabaseAdmin
    .from("inventory_items")
    .select(
      `
      id,
      code,
      name,
      item_type,
      unit,
      product_id,
      option_value_id,
      inventory_source,
      is_active
    `,
    )
    .eq("is_active", true)
    .eq("inventory_source", "PRODUCT")
    .is("option_value_id", null)
    .order("name", { ascending: true });

  if (inventoryComponentCandidatesError) {
    return NextResponse.json(
      {
        ok: false,
        message: inventoryComponentCandidatesError.message,
      },
      { status: 500 },
    );
  }

  return NextResponse.json({
    ok: true,
    products: products || [],
    optionGroups: optionGroups || [],
    salesChannels: salesChannels || [],
    inventoryComponentCandidates: inventoryComponentCandidates || [],
  });
}
