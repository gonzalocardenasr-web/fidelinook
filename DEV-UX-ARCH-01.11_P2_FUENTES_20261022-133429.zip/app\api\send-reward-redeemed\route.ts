import { NextResponse } from "next/server";

import { enqueueEmail } from "../../../lib/email/emailQueue";
import { dispatchQueuedEmailById } from "../../../lib/email/emailDispatcher";
import { getOperationSession } from "../../../lib/operation-auth";
import { authorizeOperationSession } from "@/lib/operation-rbac";
import { supabaseAdmin } from "../../../lib/supabase-admin";

async function validateOperationalUser() {
  const session = await getOperationSession();

  const authorization = authorizeOperationSession(session, "loyalty.operate");

  if (!authorization.ok) {
    return {
      ok: false,
      response: NextResponse.json(
        {
          ok: false,
          message: authorization.message,
        },
        { status: authorization.status },
      ),
    };
  }

  if (!session.ok || !session.userId) {
    return {
      error: NextResponse.json(
        { ok: false, message: "No autenticado." },
        { status: 401 },
      ),
    };
  }

  const { data: operationalUser, error } = await supabaseAdmin
    .from("operational_users")
    .select("id, role, is_active")
    .eq("id", session.userId)
    .maybeSingle();

  if (error) {
    return {
      error: NextResponse.json(
        {
          ok: false,
          message: "No fue posible validar al usuario operacional.",
        },
        { status: 500 },
      ),
    };
  }

  if (
    !operationalUser ||
    !operationalUser.is_active ||
    operationalUser.role !== session.role
  ) {
    return {
      error: NextResponse.json(
        { ok: false, message: "Usuario operacional no autorizado." },
        { status: 403 },
      ),
    };
  }

  return { error: null };
}

export async function POST(req: Request) {
  const validation = await validateOperationalUser();

  if (validation.error) {
    return validation.error;
  }

  try {
    const body = await req.json();

    const {
      email,
      nombre,
      premioNombre,
      publicToken,
      customerId,
      idempotencyKey,
      sourceReference,
    } = body;

    if (!email || !nombre || !premioNombre || !publicToken || !idempotencyKey) {
      return NextResponse.json(
        {
          error: "Faltan datos para registrar el correo de canje en la cola.",
        },
        { status: 400 },
      );
    }

    const queuedEmail = await enqueueEmail({
      recipientEmail: email,
      emailType: "REWARD_REDEEMED",
      priority: 1,
      idempotencyKey,
      payload: {
        nombre,
        premioNombre,
        publicToken,
      },
      customerId:
        Number.isInteger(Number(customerId)) && Number(customerId) > 0
          ? Number(customerId)
          : null,
      sourceType: "reward_redeemed",
      sourceReference: sourceReference != null ? String(sourceReference) : null,
      maxAttempts: 5,
    });

    const dispatchResult = await dispatchQueuedEmailById(queuedEmail.id);

    return NextResponse.json({
      ok: true,
      emailQueued: true,
      emailSent: dispatchResult.sent > 0,
      queueId: queuedEmail.id,
    });
  } catch (error) {
    console.error("Error en /api/send-reward-redeemed:", error);

    return NextResponse.json(
      {
        error: "No se pudo registrar el correo de canje.",
      },
      { status: 500 },
    );
  }
}
