"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "../../lib/supabase";
import AdminClienteDetalle from "./components/AdminClienteDetalle";
import UltimosMovimientosCard from "./components/UltimosMovimientosCard";
import OperacionSuscripcionActiva from "./components/OperacionSuscripcionActiva";
import UltimosMovimientos from "./components/UltimosMovimientos";
import OperationSummary from "../../components/operations/OperationSummary";

type Premio = {
  id: number | string;
  nombre: string;
  descripcion?: string;
  estado: "activo" | "usado" | "caducado";
  vencimiento?: string;
  tipo?: string;
  campana_id?: number;
  fecha_canje?: string;
};

type Cliente = {
  id: number;
  nombre: string;
  correo: string;
  telefono: string;
  sellos: number;
  premios: Premio[] | number | null;
  public_token: string;
  tarjeta_activa?: boolean;
  email_verificado?: boolean;
  fecha_ultimo_sello?: string | null;
  fecha_ultimo_canje?: string | null;
  created_At?: string | null;
  fecha_activacion?: string | null;
};

type Campana = {
  id: number;
  nombre_interno: string;
  premio_nombre: string;
  duracion_horas: number;
  fecha_lanzamiento: string;
  recurrencia: string;
  estado:
    | "borrador"
    | "programada"
    | "lanzando"
    | "lanzada"
    | "fallida"
    | "cancelada";
  total_objetivo?: number | null;
  total_enviados?: number | null;
  created_at?: string | null;
};

const LETRAS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("");
const META_SELLOS = 7;

export default function OperacionPage() {
  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [clienteSeleccionadoId, setClienteSeleccionadoId] =
    useState<string>("");
  const [busqueda, setBusqueda] = useState("");
  const [letraActiva, setLetraActiva] = useState<string>("TODOS");
  const [mensaje, setMensaje] = useState("");
  const [tipoMensaje, setTipoMensaje] = useState<"success" | "error" | "info">(
    "info",
  );
  const [cargando, setCargando] = useState(true);
  const [procesandoCompra, setProcesandoCompra] = useState(false);
  const [procesandoCanje, setProcesandoCanje] = useState(false);
  const [rol, setRol] = useState<"admin" | "superadmin" | null>(null);
  const [cargandoRol, setCargandoRol] = useState(true);
  const [subscriptions, setSubscriptions] = useState<any[]>([]);
  const [subscriptionSeleccionada, setSubscriptionSeleccionada] =
    useState<any>(null);
  const [cargandoSuscripcion, setCargandoSuscripcion] = useState(false);
  const [mensajeSuscripcion, setMensajeSuscripcion] = useState("");
  const [campanas, setCampanas] = useState<Campana[]>([]);
  const [cargandoCampanas, setCargandoCampanas] = useState(false);
  const [procesandoCampanaId, setProcesandoCampanaId] = useState<number | null>(
    null,
  );

  useEffect(() => {
    cargarSesion();
    cargarDatos();
    cargarCampanas();
  }, []);

  useEffect(() => {
    if (!clienteSeleccionadoId) {
      setSubscriptions([]);
      setSubscriptionSeleccionada(null);
      setMensajeSuscripcion("");
      return;
    }

    cargarSuscripcionActiva(Number(clienteSeleccionadoId));
  }, [clienteSeleccionadoId]);

  async function cargarSuscripcionActiva(clienteId: number) {
    try {
      setCargandoSuscripcion(true);
      setMensajeSuscripcion("");

      const res = await fetch(
        `/api/subscriptions/active-by-client?clienteId=${clienteId}`,
      );

      const data = await res.json();

      if (!res.ok) {
        setSubscriptions([]);
        setSubscriptionSeleccionada(null);
        return;
      }

      setSubscriptions(data.subscriptions || []);

      if (data.subscriptions?.length > 0) {
        setSubscriptionSeleccionada(data.subscriptions[0]);
      } else {
        setSubscriptionSeleccionada(null);
      }
    } catch (error) {
      console.error(error);
    } finally {
      setCargandoSuscripcion(false);
    }
  }

  const cargarSesion = async () => {
    try {
      setCargandoRol(true);

      const res = await fetch("/api/session", {
        method: "GET",
      });

      if (!res.ok) {
        setRol(null);
        return;
      }

      const data = await res.json();
      setRol(data.role || null);
    } catch (error) {
      console.error("Error cargando sesión:", error);
      setRol(null);
    } finally {
      setCargandoRol(false);
    }
  };

  const cargarDatos = async (mantenerSeleccion = true) => {
    try {
      setCargando(true);

      const { data, error } = await supabase
        .from("clientes")
        .select("*")
        .order("nombre", { ascending: true });

      if (error) {
        console.error("Error cargando clientes:", error);
        setMensaje("Error cargando clientes desde Supabase.");
        setClientes([]);
        return;
      }

      const listaClientes = (data || []) as Cliente[];
      setClientes(listaClientes);

      if (listaClientes.length === 0) {
        setClienteSeleccionadoId("");
        localStorage.removeItem("operacionClienteSeleccionadoId");
        return;
      }

      const seleccionadoGuardado = localStorage.getItem(
        "operacionClienteSeleccionadoId",
      );

      if (mantenerSeleccion && seleccionadoGuardado) {
        const existeSeleccionado = listaClientes.some(
          (c) => String(c.id) === String(seleccionadoGuardado),
        );

        if (existeSeleccionado) {
          setClienteSeleccionadoId(String(seleccionadoGuardado));
          return;
        }
      }

      const primerId = String(listaClientes[0].id);
      setClienteSeleccionadoId(primerId);
      localStorage.setItem("operacionClienteSeleccionadoId", primerId);
    } catch (err) {
      console.error("Error inesperado cargando clientes:", err);
      setMensaje("Ocurrió un error inesperado al cargar clientes.");
      setClientes([]);
    } finally {
      setCargando(false);
    }
  };

  const cargarCampanas = async () => {
    try {
      setCargandoCampanas(true);

      const { data, error } = await supabase
        .from("campanas")
        .select(
          "id, nombre_interno, premio_nombre, duracion_horas, fecha_lanzamiento, recurrencia, estado, total_objetivo, total_enviados, created_at",
        )
        .order("created_at", { ascending: false })
        .limit(20);

      if (error) {
        console.error("Error cargando campañas:", error);
        return;
      }

      setCampanas((data || []) as Campana[]);
    } catch (error) {
      console.error("Error inesperado cargando campañas:", error);
    } finally {
      setCargandoCampanas(false);
    }
  };

  const programarLanzamientoCampana = async (campanaId: number) => {
    try {
      setProcesandoCampanaId(campanaId);
      setMensaje("");
      setTipoMensaje("info");

      const res = await fetch("/api/admin/campanas/programar-lanzamiento", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ campanaId }),
      });

      const data = await res.json();

      if (!res.ok) {
        setTipoMensaje("error");
        setMensaje(data.message || "No se pudo programar la campaña.");
        return;
      }

      setTipoMensaje("success");
      setMensaje(data.message || "Campaña programada correctamente.");

      await cargarCampanas();
    } catch (error) {
      console.error("Error programando campaña:", error);
      setTipoMensaje("error");
      setMensaje("Ocurrió un error al programar la campaña.");
    } finally {
      setProcesandoCampanaId(null);
    }
  };

  const cancelarCampana = async (campanaId: number) => {
    const confirmar = window.confirm(
      "¿Seguro que quieres cancelar esta campaña?",
    );

    if (!confirmar) return;

    try {
      setProcesandoCampanaId(campanaId);
      setMensaje("");
      setTipoMensaje("info");

      const res = await fetch("/api/admin/campanas/cancelar", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ campanaId }),
      });

      const data = await res.json();

      if (!res.ok) {
        setTipoMensaje("error");
        setMensaje(data.message || "No se pudo cancelar la campaña.");
        return;
      }

      setTipoMensaje("success");
      setMensaje(data.message || "Campaña cancelada correctamente.");

      await cargarCampanas();
    } catch (error) {
      console.error("Error cancelando campaña:", error);
      setTipoMensaje("error");
      setMensaje("Ocurrió un error al cancelar la campaña.");
    } finally {
      setProcesandoCampanaId(null);
    }
  };

  const ejecutarCampanaAhora = async (campanaId: number) => {
    const confirmar = window.confirm(
      "¿Seguro que quieres ejecutar esta campaña ahora? Se asignará el premio a los clientes objetivo.",
    );

    if (!confirmar) return;

    try {
      setProcesandoCampanaId(campanaId);
      setMensaje("");
      setTipoMensaje("info");

      const res = await fetch("/api/admin/campanas/ejecutar", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ campanaId }),
      });

      const data = await res.json();

      if (!res.ok) {
        setTipoMensaje("error");
        setMensaje(data.message || "No se pudo ejecutar la campaña.");
        return;
      }

      setTipoMensaje("success");
      setMensaje(data.message || "Campaña ejecutada correctamente.");

      await cargarCampanas();
      await cargarDatos(true);
    } catch (error) {
      console.error("Error ejecutando campaña:", error);
      setTipoMensaje("error");
      setMensaje("Ocurrió un error al ejecutar la campaña.");
    } finally {
      setProcesandoCampanaId(null);
    }
  };

  const ejecutarCampanaPrueba = async (campanaId: number) => {
    const correo = window.prompt(
      "Ingresa el correo del cliente de prueba que recibirá el premio:",
    );

    if (!correo) return;

    try {
      setProcesandoCampanaId(campanaId);
      setMensaje("");
      setTipoMensaje("info");

      const res = await fetch("/api/admin/campanas/ejecutar", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          campanaId,
          clienteCorreoPrueba: correo.trim().toLowerCase(),
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setTipoMensaje("error");
        setMensaje(data.message || "No se pudo ejecutar la prueba.");
        return;
      }

      setTipoMensaje("success");
      setMensaje("Prueba ejecutada correctamente para el cliente indicado.");

      await cargarCampanas();
      await cargarDatos(true);
    } catch (error) {
      console.error("Error ejecutando prueba de campaña:", error);
      setTipoMensaje("error");
      setMensaje("Ocurrió un error al ejecutar la prueba.");
    } finally {
      setProcesandoCampanaId(null);
    }
  };

  const clientesFiltrados = useMemo(() => {
    let resultado = [...clientes];

    if (letraActiva !== "TODOS") {
      resultado = resultado.filter((cliente) => {
        const nombre = (cliente.nombre || "").trim().toLowerCase();
        return nombre.startsWith(letraActiva.toLowerCase());
      });
    }

    const texto = busqueda.trim().toLowerCase();
    if (!texto) return resultado;

    return resultado.filter((cliente) => {
      const nombre = (cliente.nombre || "").toLowerCase();
      const telefono = (cliente.telefono || "").toLowerCase();
      const correo = (cliente.correo || "").toLowerCase();

      return (
        nombre.includes(texto) ||
        telefono.includes(texto) ||
        correo.includes(texto)
      );
    });
  }, [clientes, busqueda, letraActiva]);

  const cambiarCliente = (id: string) => {
    setClienteSeleccionadoId(id);
    localStorage.setItem("operacionClienteSeleccionadoId", id);
    setMensaje("Cliente seleccionado correctamente.");
  };

  const seleccionarLetra = (letra: string) => {
    setLetraActiva(letra);
    setMensaje("");
    setTipoMensaje("info");

    const listaFiltrada =
      letra === "TODOS"
        ? clientes
        : clientes.filter((cliente) =>
            (cliente.nombre || "")
              .trim()
              .toLowerCase()
              .startsWith(letra.toLowerCase()),
          );

    if (listaFiltrada.length > 0) {
      const primerId = String(listaFiltrada[0].id);
      setClienteSeleccionadoId(primerId);
      localStorage.setItem("operacionClienteSeleccionadoId", primerId);
    }
  };

  const cliente =
    clientes.find((c) => String(c.id) === String(clienteSeleccionadoId)) ||
    null;

  const premiosArray = Array.isArray(cliente?.premios) ? cliente.premios : [];
  const premiosActivos = premiosArray.filter(
    (premio: Premio) => premio.estado === "activo",
  );

  const validarCompra = async () => {
    if (!cliente) {
      setTipoMensaje("error");
      setMensaje("Debes seleccionar un cliente.");
      return;
    }

    if (!cliente.tarjeta_activa || !cliente.email_verificado) {
      setTipoMensaje("error");
      setMensaje(
        "El cliente aún no ha activado su tarjeta. Debe verificar su correo primero.",
      );
      return;
    }

    try {
      setProcesandoCompra(true);
      setMensaje("");
      setTipoMensaje("info");

      const premiosActuales = Array.isArray(cliente.premios)
        ? cliente.premios
        : [];
      const sellosActuales = cliente.sellos ?? 0;
      const esPrimeraCompraHistorica =
        sellosActuales === 0 && premiosActuales.length === 0;
      const sellosAAgregar = esPrimeraCompraHistorica ? 2 : 1;
      const nuevosSellos = sellosActuales + sellosAAgregar;

      let sellosFinales = nuevosSellos;
      const premiosFinales = [...premiosActuales];
      let mensajeFinal = esPrimeraCompraHistorica
        ? "Primera compra registrada. Se sumaron 2 sellos."
        : "Compra validada correctamente. Se sumó 1 sello.";

      let premioGenerado: Premio | null = null;

      if (nuevosSellos >= META_SELLOS) {
        premioGenerado = {
          id: Date.now(),
          nombre: "Helado simple gratis",
          estado: "activo",
          vencimiento: new Date(
            Date.now() + 30 * 24 * 60 * 60 * 1000,
          ).toISOString(),
        };

        premiosFinales.push(premioGenerado);
        sellosFinales = 0;
        mensajeFinal = `¡Cliente completó ${META_SELLOS} sellos! Premio generado automáticamente.`;
      }

      const { error } = await supabase
        .from("clientes")
        .update({
          sellos: sellosFinales,
          premios: premiosFinales,
          fecha_ultimo_sello: new Date().toISOString(),
        })
        .eq("id", cliente.id);

      if (error) {
        console.error("Error al validar compra:", error);
        setTipoMensaje("error");
        setMensaje("Hubo un error al validar la compra.");
        return;
      }

      try {
        if (premioGenerado) {
          await fetch("/api/send-prize", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              email: cliente.correo,
              nombre: cliente.nombre,
              premioNombre: premioGenerado.nombre,
              vencimiento: premioGenerado.vencimiento,
              publicToken: cliente.public_token,
            }),
          });
        } else {
          await fetch("/api/send-stamp", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              email: cliente.correo,
              nombre: cliente.nombre,
              sellosActuales: nuevosSellos,
              metaSellos: META_SELLOS,
              publicToken: cliente.public_token,
            }),
          });
        }
      } catch (emailError) {
        console.error("Error enviando correo:", emailError);
      }

      await cargarDatos(true);
      setTipoMensaje("success");
      setMensaje(mensajeFinal);
    } catch (err) {
      console.error("Error inesperado al validar compra:", err);
      setTipoMensaje("error");
      setMensaje("Ocurrió un error inesperado al validar la compra.");
    } finally {
      setProcesandoCompra(false);
    }
  };

  const canjearPremioPorId = async (premioId: number | string) => {
    if (!cliente) {
      setTipoMensaje("error");
      setMensaje("Debes seleccionar un cliente.");
      return;
    }

    if (!cliente.tarjeta_activa || !cliente.email_verificado) {
      setTipoMensaje("error");
      setMensaje(
        "El cliente aún no ha activado su tarjeta. No es posible canjear premios.",
      );
      return;
    }

    const premiosActuales = Array.isArray(cliente.premios)
      ? cliente.premios
      : [];

    const premioActivo = premiosActuales.find(
      (premio: Premio) =>
        String(premio.id) === String(premioId) && premio.estado === "activo",
    );

    if (!premioActivo) {
      setTipoMensaje("error");
      setMensaje("No se encontró un premio activo para canjear.");
      return;
    }

    const confirmar = window.confirm(
      `¿Confirmas el canje del premio "${premioActivo.nombre}"?`,
    );

    if (!confirmar) {
      return;
    }

    try {
      setProcesandoCanje(true);
      setMensaje("");
      setTipoMensaje("info");

      const res = await fetch("/api/loyalty/redeem-reward", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          customerId: cliente.id,
          rewardId: premioActivo.id,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setTipoMensaje("error");
        setMensaje(data.message || "No se pudo completar el canje del premio.");
        return;
      }

      await cargarDatos(true);

      setTipoMensaje("success");
      setMensaje(
        data.message ||
          `Premio canjeado correctamente: ${premioActivo.nombre}.`,
      );
    } catch (error) {
      console.error("Error canjeando premio:", error);

      setTipoMensaje("error");
      setMensaje("Ocurrió un error inesperado al canjear el premio.");
    } finally {
      setProcesandoCanje(false);
    }
  };

  const cerrarSesion = async () => {
    try {
      await fetch("/api/logout", {
        method: "POST",
      });
      window.location.href = "/login";
    } catch (error) {
      console.error("Error al cerrar sesión:", error);
      setTipoMensaje("error");
      setMensaje("No se pudo cerrar sesión.");
    }
  };

  return (
    <main className="min-h-screen bg-[#F6F3FF] p-6">
      <div className="mx-auto max-w-5xl space-y-6">
        <div className="rounded-xl bg-gradient-to-r from-violet-600 to-purple-600 p-6 text-white">
          <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
            <div>
              <Link
                href="/"
                className="rounded-xl bg-white/15 px-4 py-2 text-sm font-medium text-white backdrop-blur-sm transition hover:bg-white/25"
              >
                ← Volver al inicio
              </Link>

              <h1 className="mt-3 text-2xl font-bold">Operación</h1>

              <p className="text-sm opacity-90">
                Gestión operativa de clientes, fidelización y suscripciones
              </p>

              <p className="mt-3 text-xs font-medium uppercase tracking-[0.2em] text-white/80">
                {cargandoRol
                  ? "Cargando rol..."
                  : `ROL: ${rol ?? "sin sesión"}`}
              </p>
            </div>

            <button
              onClick={cerrarSesion}
              className="cursor-pointer rounded-xl bg-white/15 px-4 py-2 text-sm font-medium text-white backdrop-blur-sm transition hover:bg-white/25"
            >
              Cerrar sesión
            </button>
          </div>
        </div>

        <OperationSummary />

        <section className="grid gap-4 md:grid-cols-5">
          <Link
            href="/operacion/ventas/nueva"
            className="rounded-2xl border border-neutral-200 bg-white p-5 shadow-sm transition hover:border-violet-300 hover:shadow-md"
          >
            <p className="text-lg font-bold text-neutral-900">Nueva Venta</p>

            <p className="mt-2 text-sm text-neutral-500">
              Crear una venta local y generar un pedido.
            </p>
          </Link>

          <Link
            href="/operacion/cola"
            className="rounded-2xl border border-neutral-200 bg-white p-5 shadow-sm transition hover:border-violet-300 hover:shadow-md"
          >
            <p className="text-lg font-bold text-neutral-900">
              Cola de Preparación
            </p>

            <p className="mt-2 text-sm text-neutral-500">
              Gestionar pedidos pendientes de entrega.
            </p>
          </Link>

          <Link
            href="/operacion/ventas"
            className="rounded-2xl border border-neutral-200 bg-white p-5 shadow-sm transition hover:border-violet-300 hover:shadow-md"
          >
            <p className="text-lg font-bold text-neutral-900">Historial</p>

            <p className="mt-2 text-sm text-neutral-500">
              Revisar ventas y pedidos recientes.
            </p>
          </Link>

          <Link
            href="/operacion/catalogo"
            className="rounded-2xl border border-neutral-200 bg-white p-5 shadow-sm transition hover:border-violet-300 hover:shadow-md active:scale-[0.98]"
          >
            <p className="text-lg font-bold text-neutral-900">Catálogo</p>

            <p className="mt-2 text-sm text-neutral-500">
              Productos, precios y opciones activas.
            </p>
          </Link>

          <Link
            href="/operacion/inventario"
            className="rounded-2xl border border-neutral-200 bg-white p-5 shadow-sm transition hover:border-violet-300 hover:shadow-md"
          >
            <p className="text-lg font-bold text-neutral-900">Inventario</p>

            <p className="mt-2 text-sm text-neutral-500">
              Recepciones, stock y movimientos de productos.
            </p>
          </Link>
        </section>

        <UltimosMovimientosCard clientes={clientes} />

        {rol === "superadmin" && (
          <section className="rounded-[24px] bg-white p-5 shadow-[0_10px_30px_rgba(0,0,0,0.06)]">
            <div className="mb-4 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.25em] text-[#7A57F6]">
                  Campañas
                </p>
                <h2 className="mt-1 text-xl font-bold text-[#222]">
                  Gestión de campañas
                </h2>
                <p className="mt-1 text-sm text-[#666]">
                  Revisa, lanza o cancela campañas antes de publicarlas.
                </p>
              </div>

              <button
                onClick={async () => {
                  const confirmar = confirm("¿Expirar premios vencidos?");
                  if (!confirmar) return;

                  const res = await fetch("/api/admin/campanas/expirar", {
                    method: "POST",
                  });

                  const data = await res.json();

                  alert(`Clientes actualizados: ${data.totalActualizados}`);

                  await cargarDatos(true);
                }}
                className="cursor-pointer mb-4 rounded-xl bg-black px-4 py-2 text-sm font-semibold text-white"
              >
                Expirar premios
              </button>

              <a
                href="/campanas"
                className="inline-flex rounded-2xl border border-[#D9C8FF] bg-white px-5 py-3 text-sm font-semibold text-[#4c00f7] transition hover:bg-[#F7F2FF]"
              >
                Crear campaña
              </a>
            </div>

            {cargandoCampanas ? (
              <div className="rounded-2xl border border-[#E7C8F2] bg-[#FCF8FF] px-4 py-3 text-sm text-[#555]">
                Cargando campañas...
              </div>
            ) : campanas.length === 0 ? (
              <div className="rounded-2xl border border-[#E7C8F2] bg-[#FCF8FF] px-4 py-3 text-sm text-[#555]">
                No hay campañas creadas.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[760px] border-separate border-spacing-y-2 text-left text-sm">
                  <thead>
                    <tr className="text-xs uppercase tracking-[0.18em] text-[#777]">
                      <th className="px-3 py-2">Campaña</th>
                      <th className="px-3 py-2">Premio</th>
                      <th className="px-3 py-2">Estado</th>
                      <th className="px-3 py-2">Lanzamiento</th>
                      <th className="px-3 py-2">Vigencia</th>
                      <th className="px-3 py-2">Alcance</th>
                      <th className="px-3 py-2 text-right">Acciones</th>
                    </tr>
                  </thead>

                  <tbody>
                    {campanas.map((campana) => {
                      const puedeLanzar =
                        campana.estado === "borrador" ||
                        campana.estado === "fallida";

                      const puedeCancelar =
                        campana.estado === "borrador" ||
                        campana.estado === "programada" ||
                        campana.estado === "fallida";

                      return (
                        <tr key={campana.id}>
                          <td className="rounded-l-2xl bg-[#FCF8FF] px-3 py-3">
                            <p className="font-semibold text-[#222]">
                              {campana.nombre_interno}
                            </p>
                            <p className="mt-1 text-xs text-[#777]">
                              #{campana.id}
                            </p>
                          </td>

                          <td className="bg-[#FCF8FF] px-3 py-3 text-[#555]">
                            {campana.premio_nombre}
                          </td>

                          <td className="bg-[#FCF8FF] px-3 py-3">
                            <span className="rounded-full bg-white px-3 py-1 text-xs font-semibold text-[#4c00f7]">
                              {campana.estado}
                            </span>
                          </td>

                          <td className="bg-[#FCF8FF] px-3 py-3 text-[#555]">
                            {new Date(campana.fecha_lanzamiento).toLocaleString(
                              "es-CL",
                              {
                                timeZone: "America/Santiago",
                                day: "2-digit",
                                month: "2-digit",
                                year: "numeric",
                                hour: "2-digit",
                                minute: "2-digit",
                              },
                            )}
                          </td>

                          <td className="bg-[#FCF8FF] px-3 py-3 text-[#555]">
                            {campana.duracion_horas} h
                          </td>

                          <td className="bg-[#FCF8FF] px-3 py-3 text-[#555]">
                            {campana.total_enviados || 0}/
                            {campana.total_objetivo || 0}
                          </td>

                          <td className="rounded-r-2xl bg-[#FCF8FF] px-3 py-3">
                            <div className="flex justify-end gap-2">
                              <a
                                href={`/campanas/${campana.id}`}
                                className="rounded-xl border border-[#D9C8FF] bg-white px-3 py-2 text-xs font-semibold text-[#4c00f7] transition hover:bg-[#F7F2FF]"
                              >
                                Ver
                              </a>

                              {puedeLanzar && (
                                <button
                                  type="button"
                                  onClick={() =>
                                    programarLanzamientoCampana(campana.id)
                                  }
                                  disabled={procesandoCampanaId === campana.id}
                                  className="rounded-xl bg-[#4c00f7] px-3 py-2 text-xs font-semibold text-white transition hover:opacity-95 disabled:opacity-60"
                                >
                                  {procesandoCampanaId === campana.id
                                    ? "Procesando..."
                                    : "Lanzar"}
                                </button>
                              )}

                              {campana.estado === "programada" && (
                                <button
                                  type="button"
                                  onClick={() =>
                                    ejecutarCampanaAhora(campana.id)
                                  }
                                  disabled={procesandoCampanaId === campana.id}
                                  className="rounded-xl bg-black px-3 py-2 text-xs font-semibold text-white transition hover:opacity-90 disabled:opacity-60"
                                >
                                  {procesandoCampanaId === campana.id
                                    ? "Ejecutando..."
                                    : "Ejecutar ahora"}
                                </button>
                              )}

                              {["borrador", "programada", "fallida"].includes(
                                campana.estado,
                              ) && (
                                <button
                                  type="button"
                                  onClick={() =>
                                    ejecutarCampanaPrueba(campana.id)
                                  }
                                  disabled={procesandoCampanaId === campana.id}
                                  className="rounded-xl border border-[#D9C8FF] bg-white px-3 py-2 text-xs font-semibold text-[#4c00f7] transition hover:bg-[#F7F2FF] disabled:opacity-60"
                                >
                                  Probar
                                </button>
                              )}

                              {puedeCancelar && (
                                <button
                                  type="button"
                                  onClick={() => cancelarCampana(campana.id)}
                                  disabled={procesandoCampanaId === campana.id}
                                  className="rounded-xl border border-[#E7C9D1] bg-white px-3 py-2 text-xs font-semibold text-[#8A3550] transition hover:bg-[#FFF1F4] disabled:opacity-60"
                                >
                                  Cancelar
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        )}

        <div className="rounded-lg border border-neutral-200 bg-white shadow-sm">
          <div className="border-b border-neutral-200 p-4">
            <span className="text-lg font-semibold text-violet-800">
              Atención en local
            </span>
          </div>

          <div className="p-4 pt-4">
            {cargando ? (
              <div className="mt-2">
                <p className="text-neutral-600">Cargando clientes...</p>
              </div>
            ) : clientes.length === 0 ? (
              <div className="mt-2">
                <p className="text-neutral-600">
                  No hay clientes registrados todavía.
                </p>

                {mensaje && (
                  <div className="mt-4 rounded-lg bg-neutral-100 p-4 text-sm text-neutral-700">
                    {mensaje}
                  </div>
                )}
              </div>
            ) : (
              <>
                <div className="mt-2 rounded-2xl border border-violet-100 bg-white p-4 shadow-sm">
                  <div className="grid gap-4">
                    <div>
                      <label className="mb-2 block text-sm font-semibold text-violet-700">
                        Buscar cliente
                      </label>
                      <input
                        type="text"
                        value={busqueda}
                        onChange={(e) => setBusqueda(e.target.value)}
                        placeholder="Nombre, teléfono o correo"
                        className="w-full rounded-xl border border-neutral-200 bg-white px-4 py-3 text-sm text-neutral-800 outline-none transition placeholder:text-neutral-400 focus:border-violet-400 focus:ring-4 focus:ring-violet-100"
                      />
                    </div>

                    <div>
                      <div className="mb-2 flex items-center justify-between gap-3">
                        <p className="text-sm font-semibold text-violet-700">
                          Filtrar por letra
                        </p>
                        <p className="text-xs text-neutral-500">
                          {clientesFiltrados.length} resultado
                          {clientesFiltrados.length === 1 ? "" : "s"}
                        </p>
                      </div>

                      <div className="flex flex-wrap gap-2">
                        <button
                          type="button"
                          onClick={() => seleccionarLetra("TODOS")}
                          className={`rounded-lg border px-3 py-2 text-xs font-medium transition ${
                            letraActiva === "TODOS"
                              ? "cursor-pointer border-transparent bg-gradient-to-r from-violet-600 to-purple-600 text-white"
                              : "cursor-pointer border-neutral-200 bg-white text-neutral-700 hover:bg-neutral-50"
                          }`}
                        >
                          Todos
                        </button>

                        {LETRAS.map((letra) => (
                          <button
                            key={letra}
                            type="button"
                            onClick={() => seleccionarLetra(letra)}
                            className={`min-w-[36px] rounded-lg border px-3 py-2 text-xs font-medium transition ${
                              letraActiva === letra
                                ? "cursor-pointer border-transparent bg-gradient-to-r from-violet-600 to-purple-600 text-white"
                                : "cursor-pointer border-neutral-200 bg-white text-neutral-700 hover:bg-neutral-50"
                            }`}
                          >
                            {letra}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="mb-2 block text-sm font-semibold text-violet-700">
                        Seleccionar cliente
                      </label>

                      <select
                        value={clienteSeleccionadoId}
                        onChange={(e) => cambiarCliente(e.target.value)}
                        className="w-full rounded-xl border border-neutral-200 bg-white px-4 py-3 text-sm text-neutral-800 outline-none transition focus:border-violet-400 focus:ring-4 focus:ring-violet-100"
                      >
                        {clientesFiltrados.length === 0 ? (
                          <option value="">No hay resultados</option>
                        ) : (
                          clientesFiltrados.map((c) => (
                            <option key={c.id} value={c.id}>
                              {c.nombre} · {c.telefono} · {c.correo}
                            </option>
                          ))
                        )}
                      </select>
                    </div>
                  </div>
                </div>

                <p className="mt-3 text-sm text-neutral-500">
                  Resultados encontrados: {clientesFiltrados.length}
                </p>

                <AdminClienteDetalle
                  cliente={cliente}
                  premiosActivos={premiosActivos}
                  mensaje={mensaje}
                  tipoMensaje={tipoMensaje}
                  setMensaje={setMensaje}
                  procesandoCompra={procesandoCompra}
                  procesandoCanje={procesandoCanje}
                  reiniciando={false}
                  rol={rol}
                  validarCompra={validarCompra}
                  canjearPremioPorId={canjearPremioPorId}
                  eliminarClienteSeleccionado={undefined}
                  reiniciarDatos={undefined}
                  exportarCSV={undefined}
                  mostrarAccionesAdministrativas={false}
                />

                {subscriptions.length > 0 && (
                  <OperacionSuscripcionActiva
                    clienteId={cliente.id}
                    subscriptions={subscriptions}
                    subscriptionSeleccionada={subscriptionSeleccionada}
                    cargando={cargandoSuscripcion}
                    onRefresh={() => cargarSuscripcionActiva(cliente.id)}
                    onMensaje={setMensajeSuscripcion}
                    onSelectSubscription={setSubscriptionSeleccionada}
                  />
                )}

                {subscriptions.length > 0 && (
                  <UltimosMovimientos clienteId={cliente.id} />
                )}

                {mensajeSuscripcion && (
                  <div className="mt-3 rounded-xl border border-violet-100 bg-violet-50 px-4 py-3 text-sm text-violet-700">
                    {mensajeSuscripcion}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}
