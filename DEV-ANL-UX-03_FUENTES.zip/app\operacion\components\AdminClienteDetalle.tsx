import QRCode from "react-qr-code";

import type {
  CustomerLoyaltySummary,
  CustomerRewardSummary,
} from "../../../lib/loyalty/customer-loyalty.types";

type Cliente = {
  id: number;
  nombre: string;
  correo: string;
  telefono: string;
  public_token: string;
  tarjeta_activa?: boolean;
  email_verificado?: boolean;
};

type Props = {
  cliente: Cliente | null;
  loyalty: CustomerLoyaltySummary | null;
  premiosActivos: CustomerRewardSummary[];
  cargandoFidelizacion: boolean;
  mensaje: string;
  tipoMensaje: "success" | "error" | "info";
  setMensaje: (value: string) => void;
  reiniciando?: boolean;
  rol: "admin" | "superadmin" | null;
  exportarCSV?: () => void;
  mostrarAccionesAdministrativas: boolean;
};

const META_SELLOS = 7;

export default function AdminClienteDetalle({
  cliente,
  loyalty,
  premiosActivos,
  cargandoFidelizacion,
  mensaje,
  tipoMensaje,
  setMensaje,
  rol,
  exportarCSV,
  mostrarAccionesAdministrativas,
}: Props) {
  if (!cliente) return null;

  const sellos = loyalty?.currentStampBalance ?? 0;
  const premiosUsados = loyalty?.redeemedRewards.length ?? 0;

  const ultimoCanje = loyalty?.redeemedRewards.reduce<string | null>(
    (fechaMasReciente, premio) => {
      if (!premio.redeemedAt) return fechaMasReciente;

      if (!fechaMasReciente) return premio.redeemedAt;

      return new Date(premio.redeemedAt).getTime() >
        new Date(fechaMasReciente).getTime()
        ? premio.redeemedAt
        : fechaMasReciente;
    },
    null,
  );

  const formatearFecha = (fecha?: string | null) => {
    if (!fecha) return "Sin registro";

    const date = new Date(fecha);

    if (Number.isNaN(date.getTime())) return "Sin registro";

    return date.toLocaleString("es-CL", {
      dateStyle: "short",
      timeStyle: "short",
    });
  };

  return (
    <>
      <div className="rounded-2xl border border-violet-100 bg-white p-5 shadow-sm">
        <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
          <div>
            <p className="text-sm font-semibold text-violet-600">
              Cliente seleccionado
            </p>

            <h2 className="mt-1 text-2xl font-bold text-neutral-900">
              {cliente.nombre}
            </h2>

            <div className="mt-2 space-y-1 text-sm text-neutral-600">
              <p>{cliente.correo}</p>
              <p>{cliente.telefono}</p>
            </div>

            <div className="mt-3 flex flex-wrap gap-2">
              <span
                className={`rounded-full px-3 py-1 text-xs font-semibold ${
                  cliente.tarjeta_activa
                    ? "bg-green-100 text-green-700"
                    : "bg-yellow-100 text-yellow-700"
                }`}
              >
                {cliente.tarjeta_activa
                  ? "Tarjeta activa"
                  : "Pendiente de activación"}
              </span>

              <span
                className={`rounded-full px-3 py-1 text-xs font-semibold ${
                  cliente.email_verificado
                    ? "bg-blue-100 text-blue-700"
                    : "bg-red-100 text-red-700"
                }`}
              >
                {cliente.email_verificado
                  ? "Correo verificado"
                  : "Correo no verificado"}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 md:min-w-[220px]">
            <div className="rounded-xl bg-violet-50 px-4 py-3">
              <p className="text-xs font-semibold uppercase tracking-wide text-violet-600">
                Sellos
              </p>
              <p className="mt-1 text-xl font-bold text-violet-700">
                {cargandoFidelizacion ? "..." : `${sellos} / ${META_SELLOS}`}
              </p>
            </div>

            <div className="rounded-xl bg-pink-50 px-4 py-3">
              <p className="text-xs font-semibold uppercase tracking-wide text-pink-600">
                Premios
              </p>
              <p className="mt-1 text-xl font-bold text-pink-700">
                {premiosActivos.length}
              </p>
            </div>
          </div>
        </div>

        <div className="mt-4 rounded-xl border border-neutral-200 bg-neutral-50 p-4">
          <p className="mb-3 text-sm font-medium text-neutral-700">
            Premios activos
          </p>

          {premiosActivos.length === 0 ? (
            <p className="text-sm text-neutral-500">
              No hay premios activos para este cliente.
            </p>
          ) : (
            <div className="space-y-3">
              {premiosActivos.map((premio) => (
                <div
                  key={premio.id}
                  className="flex items-center justify-between gap-3 rounded-2xl border border-neutral-200 bg-white p-3 shadow-sm"
                >
                  <div>
                    <p className="text-sm font-semibold text-neutral-900">
                      {premio.name}
                    </p>

                    {premio.expiresAt && (
                      <p className="mt-1 text-xs text-neutral-500">
                        Vence: {formatearFecha(premio.expiresAt)}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="mt-4 flex flex-wrap items-center gap-3">
          <a
            href={`/t/${cliente.public_token}`}
            target="_blank"
            rel="noreferrer"
            className="rounded-lg bg-neutral-900 px-4 py-2 text-sm text-white hover:opacity-90"
          >
            Abrir tarjeta
          </a>

          <button
            onClick={() => {
              const url = `${window.location.origin}/t/${cliente.public_token}`;
              navigator.clipboard.writeText(url);
              setMensaje("Link copiado al portapapeles");
            }}
            className="cursor-pointer rounded-lg bg-neutral-100 px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-200"
          >
            Copiar link
          </button>
        </div>

        <div className="mt-4 rounded-xl border border-neutral-200 bg-neutral-50 p-4">
          <p className="mb-3 text-sm font-medium text-neutral-700">
            QR tarjeta
          </p>

          <div className="inline-block rounded-lg bg-white p-3 shadow-sm">
            <QRCode
              value={`${window.location.origin}/t/${cliente.public_token}`}
              size={120}
            />
          </div>
        </div>

        <div className="mt-4 rounded-xl border border-neutral-200 bg-neutral-50 p-4">
          <p className="mb-4 text-sm font-medium text-neutral-700">
            Historial cliente
          </p>

          <div className="grid gap-3 md:grid-cols-2">
            <div className="rounded-lg bg-white p-3 shadow-sm">
              <p className="text-xs font-semibold uppercase tracking-wide text-neutral-500">
                Último movimiento
              </p>
              <p className="mt-1 text-sm font-medium text-neutral-800">
                {formatearFecha(loyalty?.lastMovementAt)}
              </p>
            </div>

            <div className="rounded-lg bg-white p-3 shadow-sm">
              <p className="text-xs font-semibold uppercase tracking-wide text-neutral-500">
                Último canje
              </p>
              <p className="mt-1 text-sm font-medium text-neutral-800">
                {formatearFecha(ultimoCanje)}{" "}
              </p>
            </div>

            <div className="rounded-lg bg-white p-3 shadow-sm">
              <p className="text-xs font-semibold uppercase tracking-wide text-neutral-500">
                Sellos actuales
              </p>
              <p className="mt-1 text-sm font-medium text-neutral-800">
                {cargandoFidelizacion
                  ? "Cargando..."
                  : `${sellos} / ${META_SELLOS}`}
              </p>
            </div>

            <div className="rounded-lg bg-white p-3 shadow-sm">
              <p className="text-xs font-semibold uppercase tracking-wide text-neutral-500">
                Premios usados
              </p>
              <p className="mt-1 text-sm font-medium text-neutral-800">
                {premiosUsados}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-6 flex flex-wrap gap-4">
        {mostrarAccionesAdministrativas && rol === "superadmin" && (
          <button
            onClick={exportarCSV}
            className="cursor-pointer rounded-lg border border-neutral-300 bg-white px-4 py-3 text-neutral-700 hover:bg-neutral-50 disabled:opacity-60"
          >
            Exportar clientes CSV
          </button>
        )}
      </div>

      {mensaje && (
        <div
          className={`mt-6 rounded-lg p-4 text-sm ${
            tipoMensaje === "success"
              ? "border border-[#D8E7C9] bg-[#F3FAEC] text-[#42622B]"
              : tipoMensaje === "error"
                ? "border border-[#E7C9D1] bg-[#FFF1F4] text-[#8A3550]"
                : "border border-[#E7C8F2] bg-[#FCF8FF] text-neutral-700"
          }`}
        >
          {mensaje}
        </div>
      )}
    </>
  );
}
